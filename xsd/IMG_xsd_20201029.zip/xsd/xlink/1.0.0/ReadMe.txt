Profile made for Kadaster

--a profile on:

This XML Schema Document named xlinks.xsd has been stored here based 
on the change request: 
OGC 05-068r1 "Store xlinks.xsd file at a fixed location"

Arliss Whiteside, 2005-11-22

